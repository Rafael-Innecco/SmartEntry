export class LockUnreachableError extends Error {
  constructor() {
    super("lock is unreachable")
    this.name = "LockUnreachableError"
  }
}

/**
 * A setup problem whose message is safe to print: it never contains keys,
 * TOTP secrets or payloads. Other startup errors may come from the radio
 * driver and are never printed verbatim.
 */
export class ConfigError extends Error {
  constructor(message: string) {
    super(message)
    this.name = "ConfigError"
  }
}

export class LockTimeoutError extends Error {
  constructor() {
    super("lock did not respond in time")
    this.name = "LockTimeoutError"
  }
}

export class LockRejectedError extends Error {
  constructor(public readonly code: number) {
    super(`lock rejected command (code ${code})`)
    this.name = "LockRejectedError"
  }
}

export class ClockUnsyncedError extends Error {
  constructor() {
    super("trusted NTP time is unavailable")
    this.name = "ClockUnsyncedError"
  }
}

export class NotFoundError extends Error {
  constructor(message: string) {
    super(message)
    this.name = "NotFoundError"
  }
}

export class ConflictError extends Error {
  constructor(message: string) {
    super(message)
    this.name = "ConflictError"
  }
}

export class LockBusyError extends Error {
  constructor() {
    super("another lock operation is still pending")
    this.name = "LockBusyError"
  }
}

export class SyncRequiredError extends Error {
  constructor() {
    super("sync required after an uncertain write")
    this.name = "SyncRequiredError"
  }
}
